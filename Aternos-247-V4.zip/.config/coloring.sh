#!/bin/sh



export RESET="\e[0m"
export RED="\e[0;31m"
export YELLOW="\e[1;33m"
export BG_BLACK="\e[40m"